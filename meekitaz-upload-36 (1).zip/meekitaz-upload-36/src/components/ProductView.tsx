"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCart } from "./CartProvider";
import type { ProductFull, Related, Sibling } from "@/lib/shopify";
import { metalOf } from "@/lib/shopify";
import type { RingVariant } from "@/lib/shopify";
import { saveSetting, diamondsUrl, loadStone } from "@/lib/setting";
import { GOLD_COLORS, hasKarat, isGoldMetal, karatsFor, karatStep } from "@/lib/karat";
import { toast } from "./Toast";
import { photoSrc, isCleaned } from "@/lib/img";

const usd = (n: number) => "$" + Math.round(n).toLocaleString("en-US");
const SW: Record<string, string> = { "Rose Gold": "#E3AE98", "Yellow Gold": "#E6C56B", "White Gold": "#E8E8EA", Platinum: "#DADCE2", Silver: "#D3D5DB", "Rose gold": "#E3AE98", "Yellow gold": "#E6C56B", "White gold": "#E8E8EA" };
const RING_METALS = ["Silver", "Platinum", "White gold", "Yellow gold", "Rose gold"];
const nm = (m: string) => { const l = m.toLowerCase(); return l.startsWith("rose") ? "Rose gold" : l.startsWith("yellow") ? "Yellow gold" : l.startsWith("white") ? "White gold" : l.startsWith("plat") ? "Platinum" : l.startsWith("silver") ? "Silver" : m; };
const FACTS: Record<string, string> = {
  Silver: "92.5% pure silver. Everyday value; can tarnish and needs polishing.",
  "10K": "41.7% gold. The most durable gold, with a slightly paler tone.",
  "14K": "58.3% gold. The classic balance of colour and strength.",
  "18K": "75% gold. The richest colour; a little softer.",
  Platinum: "95% pure platinum. Naturally white, dense and long-wearing.",
};
const COLG: Record<string, string> = { "White gold": "linear-gradient(135deg,#F4F4F6,#C9CBD2)", "Yellow gold": "linear-gradient(135deg,#F3DC8B,#D9A93C)", "Rose gold": "linear-gradient(135deg,#F2C3B2,#CF8F78)" };
/** The approved two-step picker: Silver · 10K · 14K · 18K · Platinum, then the colour (dimmed for silver and platinum). The karat prices come from our price list. */
function Material({ ns, metals, metal, karat, onMetal, onKarat }: { ns: string; metals: string[]; metal: string; karat: string; onMetal: (m: string) => void; onKarat: (k: string) => void }) {
  const golds = GOLD_COLORS.filter(g => metals.includes(g)), ks = golds.length ? karatsFor(ns) : [];
  const gold = isGoldMetal(metal);
  const items: { id: string; on: boolean; go: () => void }[] = [
    ...(metals.includes("Silver") ? [{ id: "Silver", on: metal === "Silver", go: () => onMetal("Silver") }] : []),
    ...ks.map(k => ({ id: k, on: gold && karat === k, go: () => onKarat(k) })),
    ...(metals.includes("Platinum") ? [{ id: "Platinum", on: metal === "Platinum", go: () => onMetal("Platinum") }] : []),
  ];
  const picked = metal === "Silver" ? "Silver" : metal === "Platinum" ? "Platinum" : karat;
  return (
    <>
      <div className="mk-lbl">Metal <em>{gold ? `${karat} ${metal}` : metal}</em></div>
      <div className="mk-seg" style={{ gridTemplateColumns: `repeat(${items.length},1fr)` }}>{items.map(i => (
        <button key={i.id} type="button" className={i.on ? "on" : ""} aria-pressed={i.on} onClick={i.go}>{i.id}</button>))}</div>
      <div className="mk-lbl">Colour <em>{gold ? metal : "Natural white"}</em></div>
      <div className="mk-cols">{golds.map(g => (
        <button key={g} type="button" className={`mk-col${gold && metal === g ? " on" : ""}${gold ? "" : " off"}`} aria-pressed={gold && metal === g} disabled={!gold} onClick={() => onMetal(g)}>
          <span><i style={{ background: COLG[g] }} /></span>{g.replace(" gold", "")}</button>))}</div>
      <p className="mk-hint">{FACTS[picked]}</p>
    </>
  );
}
export type RingProp = { family: RingVariant[]; shapes: { img: string; label: string }[]; ns: string };
const Ic = ({ d }: { d: string }) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>;
const TRUST = [
  ["M12 3l8 4v5c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V7zM8.5 12l2.5 2.5L15.5 10", "IGI / GIA certified diamonds"],
  ["M4 8h12a4 4 0 010 8H8M7 5L4 8l3 3", "30-day free returns"],
  ["M12 12c2-3 5-4 6-2s-1 5-4 4l-4-2c-3-1-5 0-5 2s3 3 6 0z", "Lifetime warranty"],
  ["M3 7h11v9H3zM14 10h4l3 3v3h-7zM7 17.5h.01M17 17.5h.01", "Free insured shipping"],
];

export default function ProductView({ product: p, siblings, related, ring }: { product: ProductFull; siblings: Sibling[]; related: Related[]; ring?: RingProp }) {
  const { add, busy, addRing } = useCart();
  const router = useRouter();
  const [rh, setRh] = useState(p.handle);
  const ns = ring?.ns || p.tags.find(t => /^NS-\d+$/.test(t)) || "";
  const karatOn = hasKarat(ns);
  const [karatPick, setKarat] = useState("10K");
  useEffect(() => { try { const k = sessionStorage.getItem("mk_karat"); if (k === "14K" || k === "18K") setKarat(k); } catch { /* ignore */ } }, []);
  const pickKarat = (k: string) => { setKarat(k); try { sessionStorage.setItem("mk_karat", k); } catch { /* ignore */ } };
  const cv = ring?.family.find(v => v.handle === rh) ?? null; // the ring design in the shape and metal chosen on this page
  const real = p.options.filter(o => !(o.values.length === 1 && o.values[0] === "Default Title") && o.name !== "Title");
  const [sel, setSel] = useState<Record<string, string>>(() => Object.fromEntries((p.variants[0]?.selected || []).map(s => [s.name, s.value])));
  const variant = useMemo(() => p.variants.find(v => v.selected.every(s => sel[s.name] === s.value)) || p.variants[0], [p, sel]);
  const [slide, setSlide] = useState(0);
  const car = useRef<HTMLDivElement>(null);
  const metal = metalOf(p.tags);
  const save = variant.compareAt ? variant.compareAt - variant.price : 0;
  const details = p.tags.filter(t => !/gold|silver|platinum|rose|yellow|white|^NS-|^CBR$|express|normal_side|^RJ-/i.test(t)).slice(0, 4);
  const imgs = cv ? cv.images.map(u => ({ url: u, alt: cv.title, width: 1000, height: 1000 })) : p.images;
  const metalNow = nm(cv ? cv.metal : metal || "");
  const karat = karatsFor(ns).includes(karatPick as "10K") ? karatPick : "10K"; // a design only offers the karats of its price list
  const step = karatOn && isGoldMetal(metalNow) ? karatStep(ns, karat) : 0;
  const kLabel = karatOn && isGoldMetal(metalNow) ? karat : "";
  const baseP = cv ? cv.price : variant.price, baseC = cv ? cv.compareAt : variant.compareAt;
  const title = cv ? cv.title : p.title, price = baseP + step, compareAt = baseC > 0 ? baseC + 2 * step : 0;
  const shapesHere = ring ? ring.shapes.filter(s => ring.family.some(v => v.shape === s.label)) : [];
  const metalsHere = cv && ring ? RING_METALS.filter(m => ring.family.some(v => v.shape === cv.shape && v.metal === m)) : [];
  const pickRing = (shape: string, metal: string) => {
    const next = ring?.family.find(v => v.shape === shape && v.metal === metal) || ring?.family.find(v => v.shape === shape);
    if (!next) return; setRh(next.handle); setSlide(0); car.current?.scrollTo({ left: 0 });
    window.history.replaceState(null, "", `/products/${next.handle}`);
  };
  const chooseSetting = () => {
    if (!cv || !ring) return;
    const stone = loadStone();
    // a diamond is already chosen: the ring is that setting in the shape of the diamond, and it goes into the bag
    let pick = cv;
    if (stone && stone.shape !== cv.shape) {
      const alt = ring.family.find(v => v.shape === stone.shape && v.metal === cv.metal) || ring.family.find(v => v.shape === stone.shape);
      if (!alt) { toast(`This setting is not made in ${stone.shape.toLowerCase()}. Pick another setting for your ${stone.shape.toLowerCase()} diamond.`); return; }
      pick = alt;
    }
    const pk = karatOn && isGoldMetal(pick.metal) ? karat : "";
    const setting = { ns: ring.ns, handle: pick.handle, variantId: pick.variantId, title: pick.title, shape: pick.shape, metal: pick.metal, price: pick.price + (pk ? karatStep(ring.ns, pk) : 0), image: pick.images[0] || "", karat: pk || undefined };
    saveSetting(setting);
    if (!stone) { router.push(diamondsUrl(pick.shape)); return; }
    addRing(setting, stone);
  };

  return (
    <main className="pp">
      <div className="wrap">
        <p className="pp-crumb"><Link href="/">Home</Link> / {p.productType || "Shop"}{metal ? ` / ${metal}` : ""}</p>
        <div className="pp-grid">
          {/* desktop: stacked gallery */}
          <div className="pp-gal">
            {imgs.map((im, i) => (
              <figure key={im.url} className={i === 0 ? "first" : ""}>
                <Image src={photoSrc(im.url, 1100, title, i)} alt={im.alt} fill sizes="(max-width:1100px) 50vw, 620px" quality={78} priority={i === 0} unoptimized={isCleaned(photoSrc(im.url, 1100, title, i))} />
              </figure>
            ))}
          </div>
          {/* phone: swipe */}
          <div className="pp-carw">
            <div className="pp-car" ref={car} onScroll={() => car.current && setSlide(Math.round(car.current.scrollLeft / car.current.clientWidth))}>
              {imgs.map((im, i) => <figure key={im.url}><Image src={photoSrc(im.url, 900, title, i)} alt={im.alt} fill sizes="100vw" quality={75} priority={i === 0} unoptimized={isCleaned(photoSrc(im.url, 900, title, i))} /></figure>)}
            </div>
            {imgs.length > 1 && <span className="pp-cnt">{slide + 1} / {imgs.length}</span>}
          </div>

          <div className="pp-info">
            <small className="eyebrow">Lab-grown · IGI certified</small>
            <h1>{title}{kLabel ? <em className="pp-k"> · {kLabel}</em> : null}</h1>
            <div className="pp-price"><b>{usd(price)}</b>{compareAt > 0 && <><s>{usd(compareAt)}</s><i>{ring ? "Setting only" : `Save ${usd(compareAt - price)}`}</i></>}</div>
            <p className="pp-sub">{ring ? "Choose the setting first. Next, pick your diamond." : "Serious diamonds, worn lightly."}</p>

            {ring && cv && (
              <>
                <span className="pp-lbl">Shape · {cv.shape}</span>
                <div className="rp-shapes">{shapesHere.map(sh => (
                  <button key={sh.label} type="button" className={`rp-sh${cv.shape === sh.label ? " on" : ""}`} aria-pressed={cv.shape === sh.label} onClick={() => pickRing(sh.label, cv.metal)}>
                    <i><Image src={sh.img} alt="" fill sizes="64px" quality={60} /></i><b>{sh.label}</b></button>))}</div>
                {karatOn ? (
                  <Material ns={ns} metals={metalsHere} metal={cv.metal} karat={karat} onMetal={m => pickRing(cv.shape, m)}
                    onKarat={k => { pickKarat(k); if (!isGoldMetal(cv.metal)) pickRing(cv.shape, GOLD_COLORS.find(g => metalsHere.includes(g)) || cv.metal); }} />
                ) : (<>
                  <span className="pp-lbl">Metal · {cv.metal}</span>
                  <div className="rp-metals">{metalsHere.map(m => (
                    <button key={m} type="button" className={`rp-mt${cv.metal === m ? " on" : ""}`} aria-pressed={cv.metal === m} onClick={() => pickRing(cv.shape, m)}>
                      <span className="rp-sw"><i style={{ background: SW[m] || "#ddd" }} /></span>{m.replace(" gold", "")}</button>))}</div>
                </>)}
              </>
            )}

            {!ring && karatOn && siblings.length > 0 && (
              <Material ns={ns} metals={siblings.map(s => nm(s.metal))} metal={metalNow} karat={karat}
                onMetal={m => { const t = siblings.find(s => nm(s.metal) === m); if (t && t.handle !== p.handle) router.replace(`/products/${t.handle}`, { scroll: false }); }}
                onKarat={k => { pickKarat(k); if (!isGoldMetal(metalNow)) { const t = siblings.find(s => isGoldMetal(nm(s.metal))); if (t) router.replace(`/products/${t.handle}`, { scroll: false }); } }} />
            )}
            {!ring && !karatOn && siblings.length > 1 && (
              <>
                <span className="pp-lbl">Metal{metal ? ` · ${metal}` : ""}</span>
                <div className="pp-sw">
                  {siblings.map(s => (
                    <Link key={s.handle} href={`/products/${s.handle}`} aria-label={s.metal} className={s.handle === p.handle ? "on" : ""} replace scroll={false}><i style={{ background: SW[s.metal] || "#ddd" }} /></Link>
                  ))}
                </div>
              </>
            )}

            {real.map(o => (
              <div key={o.name}>
                <span className="pp-lbl">{o.name} · {sel[o.name]}</span>
                <div className="pp-pills">{o.values.map(val => <button key={val} type="button" className={sel[o.name] === val ? "on" : ""} onClick={() => setSel({ ...sel, [o.name]: val })}>{val}</button>)}</div>
              </div>
            ))}

            <div className="pp-cta">
              {ring && cv ? (
                <button type="button" className="pp-add" onClick={chooseSetting}>Choose this setting<small>Next: pick your {cv.shape.toLowerCase()} diamond</small></button>
              ) : (
                <button type="button" className="pp-add" disabled={busy || !variant.available} onClick={async () => { const r = await add(variant.id, 1, step ? karat : ""); if (!r.ok) toast(r.error === "not_configured" ? "This gold option is being connected for checkout. Please book an appointment and we will complete it with you." : "We could not add this to your bag. Please try again."); }}>{!variant.available ? "Sold out" : busy ? "Adding…" : `Add to bag · ${usd(price)}`}</button>
              )}
              <Link href="/#contact" className="pp-appt">Book a private appointment</Link>
            </div>
            <div className="pp-trust">{TRUST.map(([d, t]) => <div key={t}><Ic d={d} />{t}</div>)}</div>

            <div className="pp-acc">
              <details open><summary>Description</summary><div className="pp-desc" dangerouslySetInnerHTML={{ __html: p.descriptionHtml }} /></details>
              <details><summary>Details</summary><ul><li>Lab-grown diamonds, independently certified</li>{metal && <li>Metal: {metal}</li>}{details.map(t => <li key={t}>{t}</li>)}</ul></details>
              <details><summary>Shipping &amp; returns</summary><p>Free insured shipping. Returns within 30 days. Every piece arrives in a Meekitaz box with its certificate.</p></details>
              <details><summary>Care</summary><p>Store separately, avoid harsh chemicals, and clean with warm water and a soft brush. Complimentary cleaning for life at our showroom.</p></details>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section className="pp-look">
            <small className="eyebrow">Complete the look</small><h2>You may also like</h2>
            <div className="pp-lk">
              {related.map(r => (
                <Link key={r.handle} href={`/products/${r.handle}`}>
                  <div className="im">{r.image && <Image src={photoSrc(r.image, 500, r.title)} alt={r.title} fill sizes="(max-width:767px) 50vw, 280px" quality={70} unoptimized={isCleaned(photoSrc(r.image, 500, r.title))} />}</div>
                  <b>{r.title.length > 52 ? r.title.slice(0, 50) + "…" : r.title}</b>
                  <span>{usd(r.price)}{r.compareAt > 0 && <s>{usd(r.compareAt)}</s>}</span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>

      <div className="pp-sbar">
        <div><b>{usd(price)}</b>{compareAt > 0 && <s>{usd(compareAt)}</s>}</div>
        {ring && cv ? <button type="button" className="pp-add" onClick={chooseSetting}>Choose this setting</button> : <button type="button" className="pp-add" disabled={busy || !variant.available} onClick={() => add(variant.id)}>{variant.available ? "Add to bag" : "Sold out"}</button>}
      </div>
    </main>
  );
}
